﻿namespace TaskListMvc.Models
{
    public class TaskItem
    {
        public int Id { get; set; }      // Simple identifier
        public string Title { get; set; } = string.Empty; // Task title
        public bool IsDone { get; set; } // Completion flag
    }
}
