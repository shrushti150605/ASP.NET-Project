using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaskListMvc.Views.Tasks
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
