﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using TaskListMvc.Models;

namespace TaskListMvc.Controllers
{
    public class TasksController : Controller
    {
        private static List<TaskItem> _tasks = new();
        private static int _nextId = 1;
        private static readonly string _filePath = Path.Combine(Directory.GetCurrentDirectory(), "tasks.json");

        public TasksController()
        {
            LoadTasks(); // Load tasks when controller is created
        }

        public IActionResult Index(string? q)
        {
            var list = string.IsNullOrWhiteSpace(q)
                ? _tasks
                : _tasks.Where(t => t.Title.Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();

            ViewData["SearchTerm"] = q;
            return View(list);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(TaskItem item)
        {
            if (string.IsNullOrWhiteSpace(item.Title))
            {
                ModelState.AddModelError(nameof(item.Title), "Title is required.");
                return View(item);
            }

            item.Id = _nextId++;
            item.IsDone = false;
            _tasks.Add(item);
            SaveTasks(); // Save after adding
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult Toggle(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            task.IsDone = !task.IsDone;
            SaveTasks(); // Save after toggle
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            _tasks.Remove(task);
            SaveTasks(); // Save after delete
            return RedirectToAction(nameof(Index));
        }

        private void SaveTasks()
        {
            var json = JsonSerializer.Serialize(_tasks);
            System.IO.File.WriteAllText(_filePath, json);
        }

        private void LoadTasks()
        {
            if (System.IO.File.Exists(_filePath))
            {
                var json = System.IO.File.ReadAllText(_filePath);
                _tasks = JsonSerializer.Deserialize<List<TaskItem>>(json) ?? new List<TaskItem>();
                _nextId = _tasks.Any() ? _tasks.Max(t => t.Id) + 1 : 1;
            }
        }
    }
}
